
public class EnergyLog extends LogManager {

	public EnergyLog(String fileName) {
		super(fileName);
	}
	
	

}
