
public class StationLog extends LogManager{

	public StationLog(String fileName) {
		super(fileName);
	}

}
