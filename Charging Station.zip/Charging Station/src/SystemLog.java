
public class SystemLog extends LogManager {

	public SystemLog(String fileName) {
		super(fileName);
	}
	
	

}
